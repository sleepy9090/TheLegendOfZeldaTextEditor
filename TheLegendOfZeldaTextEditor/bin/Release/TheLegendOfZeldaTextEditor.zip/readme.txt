The Legend of Zelda Text Editor
Programmed by: Shawn M. Crawford
Last Update: August 20th, 2016 in C#
Latest Build: 1.0.0.27292
 ----

Features:
	* edit every line of text in the game (title, H.U.D., registration screen, ending and credits, story, etc, etc)
	* this version tested with US rom (Legend of Zelda, The (USA).nes), might work with other versions but untested because it relies on offsets in the ROM

Requires:
	* .Net Framework 4.5
        * Windows 7+

Usage:
	*Open the Rom (Legend of Zelda, The (USA).nes), change text, click update, make sure you have a backup in case something breaks.
	*Feel free to email bugs to sleepy3d@gmail.com

 ----
1.0.0.27292  August 20th, 2016
-initial release
 ----